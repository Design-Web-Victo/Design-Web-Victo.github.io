# Examen2_correction

### Pour les inputs
- placeholder



### Champs

no_da 2040280 valider que c'est des seulement des chiffres et qu'il y en a 7  