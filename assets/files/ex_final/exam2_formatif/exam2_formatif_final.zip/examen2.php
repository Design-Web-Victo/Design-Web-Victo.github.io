

<!DOCTYPE html>

<html>

    <head>
        <meta charset="utf-8">

        <title>Examen 2 - Javascript</title>

        <style>
            body, html {
                margin: 0px;
                background-color: #1d2027;
            }

            #page_container {
                height: 100vh;
                display: flex;
                justify-content: center;
                align-items: center;

                background-image: url("./background_examen2.jpg");
                background-position: center;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-size: cover;

                color: #1d2027;
            }

            #center_container {
                background-color: rgba(255, 255, 255, 0.9);
                padding: 20px;
                border-radius: 10px;
                width: 30%;
            }

            h1 {
                text-align: center;
            }

            p {
                text-align: justify;
            }
        </style>
        
    </head>

    <body>
        <div id="page_container">
            <div id="center_container">
                <h1>Le formulaire a été envoyé</h1> 
                <p>J'espère que tout fonctionne et que ce n'est pas à cause d'un bug dans votre script.</p>
                <p>Oubliez pas d'aller voir dans la console 😉</p>
                <p>Si vous avez terminé et que vous avez bien revisé la grille de correction, oubliez pas de faire un commit et de push le tout.</p>
            </div>
        </div>
    </body>

</html>